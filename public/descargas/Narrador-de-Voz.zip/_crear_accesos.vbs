' Crea el acceso directo en el Escritorio y en el Inicio automatico de Windows.
' Se llama desde Instalar.bat pasando la carpeta destino como argumento.
Dim dest, shell, desktop, startup, acceso

If WScript.Arguments.Count < 1 Then WScript.Quit 1
dest = WScript.Arguments(0)

Set shell = CreateObject("WScript.Shell")
desktop = shell.SpecialFolders("Desktop")
startup = shell.SpecialFolders("Startup")

Set acceso = shell.CreateShortcut(desktop & "\Narrador de Voz.lnk")
acceso.TargetPath = dest & "\Iniciar_NarradorDeVoz.vbs"
acceso.IconLocation = dest & "\narrador_icon.ico"
acceso.WorkingDirectory = dest
acceso.Description = "Narrador de Voz - lee en voz alta el texto seleccionado"
acceso.Save

Set acceso2 = shell.CreateShortcut(startup & "\Narrador de Voz.lnk")
acceso2.TargetPath = dest & "\Iniciar_NarradorDeVoz.vbs"
acceso2.IconLocation = dest & "\narrador_icon.ico"
acceso2.WorkingDirectory = dest
acceso2.Description = "Narrador de Voz - inicio automatico"
acceso2.Save
