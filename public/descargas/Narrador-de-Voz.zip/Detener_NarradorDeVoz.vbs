' Cierra el Narrador de Voz si esta corriendo
Dim sh
Set sh = CreateObject("WScript.Shell")
sh.Run "taskkill /F /IM NarradorDeVoz.exe", 0, True
