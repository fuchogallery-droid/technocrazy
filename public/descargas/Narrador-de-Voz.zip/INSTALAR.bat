@echo off
title Instalando Narrador de Voz
setlocal

set "DEST=%LOCALAPPDATA%\NarradorDeVoz"

echo ============================================
echo    Instalando Narrador de Voz X-1
echo ============================================
echo.

if not exist "%DEST%" mkdir "%DEST%"

echo Cerrando el programa si esta abierto...
taskkill /F /IM NarradorDeVoz.exe >nul 2>&1
taskkill /F /IM piper_server.exe >nul 2>&1

echo Copiando archivos...
copy /Y "%~dp0NarradorDeVoz.exe" "%DEST%\" >nul
copy /Y "%~dp0narrador_icon.ico" "%DEST%\" >nul
if not exist "%DEST%\narrador_config.json" copy /Y "%~dp0narrador_config.json" "%DEST%\" >nul
copy /Y "%~dp0Iniciar_NarradorDeVoz.vbs" "%DEST%\" >nul
copy /Y "%~dp0Detener_NarradorDeVoz.vbs" "%DEST%\" >nul
robocopy "%~dp0motor" "%DEST%\motor" /MIR /NFL /NDL /NJH /NJS /NP >nul

echo Creando acceso directo en el Escritorio e inicio automatico...
cscript //nologo "%~dp0_crear_accesos.vbs" "%DEST%"

echo.
echo ============================================
echo   Listo! Narrador de Voz quedo instalado.
echo ============================================
echo.
echo - Acceso directo creado en el Escritorio: "Narrador de Voz"
echo - Se abrira automaticamente cada vez que enciendas el PC
echo - Atajo por defecto: Ctrl + Bloq Mayus (activa y detiene la narracion)
echo - La primera vez Windows pedira permiso de Administrador: dale "Si"
echo.
echo Abriendo el programa por primera vez...
start "" "%DEST%\Iniciar_NarradorDeVoz.vbs"

echo.
echo Puedes cerrar esta ventana.
pause
