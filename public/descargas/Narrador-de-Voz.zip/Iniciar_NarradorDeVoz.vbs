' Lanza Narrador de Voz como Administrador (necesario para que el atajo
' funcione dentro de Chrome/Edge y otras apps). Windows pedira permiso
' una sola vez con el aviso de Control de Cuentas de Usuario.
Dim fso, carpeta, exePath, oShell
Set fso = CreateObject("Scripting.FileSystemObject")
carpeta = fso.GetParentFolderName(WScript.ScriptFullName)
exePath = carpeta & "\NarradorDeVoz.exe"

Set oShell = CreateObject("Shell.Application")
oShell.ShellExecute exePath, "", carpeta, "runas", 1
